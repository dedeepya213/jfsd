package com.example.sdpproject;

public interface DoctorDAO {
	public void insert(DoctorUser d);
	public void delete(int id);
}
