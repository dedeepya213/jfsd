package com.example.sdpproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorDAOClass implements DoctorDAO {
	
	DoctorRepo repo;
	
	
	@Autowired
	public DoctorDAOClass(DoctorRepo repo) {
		this.repo = repo;
	}

	@Override
	public void insert(DoctorUser d) {
		repo.save(d);
		
	}

	@Override
	public void delete(int id) {
		repo.deleteById(id);
		
	}
	
}
