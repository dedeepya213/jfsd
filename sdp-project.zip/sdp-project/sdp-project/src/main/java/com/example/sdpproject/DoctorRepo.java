package com.example.sdpproject;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorRepo extends JpaRepository<DoctorUser, Integer> {

}
