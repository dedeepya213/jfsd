package com.example.sdpproject;

public interface PatientDAO {
	public void insert(PatientUser p);
	public void delete(int id);
}
