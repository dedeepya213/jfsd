package com.example.sdpproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PatientDAOClass implements PatientDAO {
	
	PatientRepo pr;
	

	@Autowired
	public PatientDAOClass(PatientRepo pr) {
		this.pr = pr;
	}

	@Override
	public void insert(PatientUser p) {
		pr.save(p);
		
	}

	@Override
	public void delete(int id) {
		pr.deleteById(id);
	}

}
