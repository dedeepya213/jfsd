package com.example.sdpproject;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;


@Controller
public class Rest {
	
	
	PatientDAOClass pd;
	
	DoctorDAOClass  dd;
	
	
	
	
	public Rest() {
	}

	@Autowired
	public Rest(PatientDAOClass pd, DoctorDAOClass dd) {
		this.pd = pd;
		this.dd = dd;
	}

	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/signup")
	public String register(Model model) {
		model.addAttribute("doc1", new DoctorUser());
		return "register";
	}
	
	@GetMapping("/insert")
	public String display(Model model, @ModelAttribute("patient2") DoctorUser p2){
		model.addAttribute("doc1",p2);
		dd.insert(p2);
		return "display";
	}
}
