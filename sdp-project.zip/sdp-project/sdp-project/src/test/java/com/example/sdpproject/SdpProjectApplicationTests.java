package com.example.sdpproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdpProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
